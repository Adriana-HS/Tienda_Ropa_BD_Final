using System.Windows;

namespace TiendaRopaPOS
{
    public partial class App : Application
    {
    }
}

